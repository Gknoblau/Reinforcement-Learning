Creators:

Bryce Cartman
Greg Knoblauch

We implemented q-learning rather than expected sarsa as we could not get expected sarsa to work. The value we used to get better returns were epsilon of 0.01. We tried a variety of different methods including the num of tiles to 8. But those were mixed results.

Thanks for a great semester!